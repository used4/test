<?php include __DIR__ . '/includes/auth_guard.php'; ?>
<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'devop';
$page_name = 'dev_option';
$data = ['eduuid' => 'disable','maxpg' => '8' , 'macmod' => '1'];

$db->insertIfEmpty($table_name, $data);

$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php'</script>";
}


?>
<!-- Form Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Advance Options</h6>
                    <form method="post">
                        <label for="exampleInputEmail1" class="form-label">Edit DNS UUID</label>
                        <select class="form-select mb-3" id="eduuid" name="eduuid">
                            <option value="enable" <?=$res[0]['eduuid']=='enable'?'selected':'' ?>>Enable</option>
							<option value="disable" <?=$res[0]['eduuid']=='disable'?'selected':'' ?>>Disable</option>
                        </select>
                        
                        <label for="exampleInputEmail1" class="form-label">Mac User Results per page</label>
                        <select class="form-select mb-3" id="maxpg" name="maxpg">
                            <option value="2" <?=$res[0]['maxpg']=='2'?'selected':'' ?>>2 pages</option>
							<option value="5" <?=$res[0]['maxpg']=='5'?'selected':'' ?>>5 pages</option>
							<option value="8" <?=$res[0]['maxpg']=='8'?'selected':'' ?>>8 pages</option>
							<option value="10" <?=$res[0]['maxpg']=='10'?'selected':'' ?>>10 pages</option>
							<option value="15" <?=$res[0]['maxpg']=='15'?'selected':'' ?>>15 pages</option>
							<option value="20" <?=$res[0]['maxpg']=='20'?'selected':'' ?>>20 pages</option>
							<option value="25" <?=$res[0]['maxpg']=='25'?'selected':'' ?>>25 pages</option>
							<option value="30" <?=$res[0]['maxpg']=='30'?'selected':'' ?>>30 pages</option>
							<option value="40" <?=$res[0]['maxpg']=='40'?'selected':'' ?>>40 pages</option>
							<option value="50" <?=$res[0]['maxpg']=='50'?'selected':'' ?>>50 pages</option>
                        </select>
                        
                        
                        <label for="exampleInputEmail1" class="form-label">Mac generate method</label>
                        <select class="form-select mb-3" id="macmod" name="macmod">
                            <option value="1" <?=$res[0]['macmod']=='1'?'selected':'' ?>>Basic method</option>
							<option value="2" <?=$res[0]['macmod']=='2'?'selected':'' ?>>Advance method</option>
							<option value="3" <?=$res[0]['macmod']=='3'?'selected':'' ?>>Numbers Only [Ex : 12:15:16:18:11:25]</option>
                            <option value="4" <?=$res[0]['macmod']=='4'?'selected':'' ?>>Text Only [Ex : bc:cc:fc:ec:ff:de]</option>
                        </select>
                        <button type="submit" name="submit" class="btn btn-primary">Update Advance Options</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>
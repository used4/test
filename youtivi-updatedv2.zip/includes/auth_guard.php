<?php
include __DIR__ . '/bootstrap.php';
if (empty($_SESSION['loggedin'])) {
    error_log("[AUTH_REDIRECT] not logged in; id=" . session_id() . "; cookie=" . (isset($_COOKIE[session_name()]) ? 'present' : 'absent') . "; path=" . ini_get('session.cookie_path'));
    redirect('index.php');
}

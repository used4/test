<?php
require __DIR__ . '/includes/bootstrap.php';
header('Content-Type: text/plain; charset=UTF-8');
echo "BASE=" . (app_base_path() ?: '/') . "\n";
echo "SESSION NAME=" . session_name() . "\n";
echo "COOKIE PATH=" . ini_get('session.cookie_path') . "\n";
echo "ERROR LOG=" . ini_get('error_log') . "\n";
$_SESSION['probe'] = ($_SESSION['probe'] ?? 0) + 1;
echo "SESSION OK, probe=" . $_SESSION['probe'] . "\n";
?>

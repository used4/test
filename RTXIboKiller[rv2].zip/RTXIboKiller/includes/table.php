<?php


$tables = [
	"user" => [
		"id" => "INTEGER PRIMARY KEY",
		"username" => "TEXT NOT NULL",
		"password" => "TEXT NOT NULL",
	],
	"int" => [
		"id" => "INTEGER PRIMARY KEY",
		"intro" => "TEXT NOT NULL",
	],
	"name" => [
		"id" => "INTEGER PRIMARY KEY",
		"fname" => "TEXT NOT NULL",
		"parto" => "TEXT NOT NULL",
		"partt" => "TEXT NOT NULL",
	],
	"ibof" => [
		"id" => "INTEGER PRIMARY KEY",
		"plid" => "TEXT NOT NULL",
		"name" => "TEXT NOT NULL",
		"macad" => "TEXT NOT NULL",
		"uuid" => "TEXT NOT NULL",
		"username" => "TEXT NOT NULL",
		"password" => "TEXT NOT NULL",
		"cdate" => "TEXT NOT NULL",
		"udate" => "TEXT NOT NULL",
		"mark" => "TEXT NOT NULL",
	],
	"mactb" => [
		"id" => "INTEGER PRIMARY KEY",
		"name" => "TEXT NOT NULL",
		"macad" => "TEXT NOT NULL",
		"expir" => "TEXT NOT NULL",
		"cdate" => "TEXT NOT NULL",
		"udate" => "TEXT NOT NULL",
		"blok" => "TEXT NOT NULL",
	],
	"noti" => [
		"id" => "INTEGER PRIMARY KEY",
		"tital" => "TEXT NOT NULL",
		"content" => "TEXT NOT NULL",
	],
	"themes" => [
		"id" => "INTEGER PRIMARY KEY",
		"themeid" => "TEXT NOT NULL",
	],
	"spapi" => [
		"id" => "INTEGER PRIMARY KEY",
		"apikey" => "TEXT NOT NULL",
	],
	"dns" => [
		"id" => "INTEGER PRIMARY KEY",
		"title" => "TEXT",
		"url" => "TEXT",
		"uid" => "TEXT",
	],
	"sort" => [
		"id" => "INTEGER PRIMARY KEY",
		"sort" => "TEXT NOT NULL",
	],
	"sortm" => [
		"id" => "INTEGER PRIMARY KEY",
		"sort" => "TEXT NOT NULL",
	],
	"actreq" => [
		"id" => "INTEGER PRIMARY KEY",
    	"mac" => "TEXT",
		"date" => "TEXT",
		"remark" => "TEXT",
	],
	"leaguesx" => [
		"id" => "INTEGER PRIMARY KEY",
    	"league" => "TEXT",
    	"leagueId" => "TEXT",
    	"lsports" => "TEXT",
    	
	],
	"devop" => [
		"id" => "INTEGER PRIMARY KEY",
    	"eduuid" => "TEXT",
    	"maxpg" => "TEXT",
    	
	],
	
];

?>
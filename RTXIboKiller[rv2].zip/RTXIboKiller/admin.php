<!-- index.php -->
<?php 
include ('includes/header.php');

$superusername = getmodsbyid('1') ?? 'superadmin';
$superpassword = getmodsbyid('2') ?? 'superadmin';




    $page_name = 'admin';
    $page_name_main = 'main';
    
    if ($_SESSION['name'] == $superusername || $_SESSION['passwordxyz'] == $superpassword){
        //echo "<script>window.location.href='" . $page_name . ".php'</script>";
    }else{
        echo "<script>window.location.href='" . $page_name_main . ".php'</script>";
    }


if (isset($_POST['submit']) && isset($_POST['data'])) {
    foreach ($_POST['data'] as $id => $fields) {
        updateJsonRecordByIdMulty($id, $fields);
    }

    echo "<script>window.location.href='" . $page_name . ".php'</script>";
}



?>
        <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h2 class="mb-4">Super Admin Credentials</h2>
                            <h7 class="mb-4 text-info">‼️ This page will automatically hide once you change your Super Admin Credentials. Logout and login again via Super Admin. ‼️</h7>
                            <br><br>
                            <form  method="post">
                                <div class="mb-3">
                                    <input type="hidden" name="data[1][preffile]" value="SuperUserUser">
                                    <input type="hidden" name="data[1][preftype]" value="string">
                                    <input type="hidden" name="data[1][prefname]" value="username">
                                    <label for="exampleInputEmail1" class="form-label">User name or Email address</label>
                                    <input type="text" name="data[1][mods]" class="form-control" value="<?php echo (getmodsbyid('1')) ; ?>"required>
                                    <div id="emailHelp" class="form-text">We'll never share your email or username with anyone else.
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <input type="hidden" name="data[2][preffile]" value="SuperUserpass">
                                    <input type="hidden" name="data[2][preftype]" value="string">
                                    <input type="hidden" name="data[2][prefname]" value="password">
                                    <label  class="form-label">Password</label>
                                    <input type="text" name="data[2][mods]" class="form-control" value="<?php echo (getmodsbyid('2')) ; ?>" id="exampleInputPassword1" required>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Update Credentials</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h2 class="mb-4">Branding</h6>
                            <form  method="post">
                                <div class="mb-3">
                                    <input type="hidden" name="data[4][preffile]" value="BrandName">
                                    <input type="hidden" name="data[4][preftype]" value="string">
                                    <input type="hidden" name="data[4][prefname]" value="BrandName">
                                    <label for="exampleInputEmail1" class="form-label">Brand Name</label>
                                    <input type="text" name="data[4][mods]" class="form-control" value="<?php echo (getmodsbyid('4')) ; ?>"required>
                                </div>
                                <div class="mb-3">
                                    <input type="hidden" name="data[5][preffile]" value="Vision">
                                    <input type="hidden" name="data[5][preftype]" value="string">
                                    <input type="hidden" name="data[5][prefname]" value="Vision">
                                    <label  class="form-label">Vision</label>
                                    <input type="text" name="data[5][mods]" class="form-control" value="<?php echo (getmodsbyid('5')) ; ?>"required>
                                </div>
                                <div class="mb-3">
                                    <input type="hidden" name="data[3][preffile]" value="Telegram">
                                    <input type="hidden" name="data[3][preftype]" value="string">
                                    <input type="hidden" name="data[3][prefname]" value="Telegram">
                                    <label  class="form-label">Telegram or Web Link</label>
                                    <input type="text" name="data[3][mods]" class="form-control" value="<?php echo (getmodsbyid('3')) ; ?>"required>
                                </div>
                                
                                <div class="mb-3">
                                    <input type="hidden" name="data[6][preffile]" value="Email">
                                    <input type="hidden" name="data[6][preftype]" value="string">
                                    <input type="hidden" name="data[6][prefname]" value="Email">
                                    <label  class="form-label">Email</label>
                                    <input type="text" name="data[6][mods]" class="form-control" value="<?php echo (getmodsbyid('6')) ; ?>"required>
                                </div>
                                <div class="mb-3">
                                    <input type="hidden" name="data[7][preffile]" value="Whatsapp">
                                    <input type="hidden" name="data[7][preftype]" value="string">
                                    <input type="hidden" name="data[7][prefname]" value="Whatsapp">
                                    <label  class="form-label">Whatsapp</label>
                                    <input type="text" name="data[7][mods]" class="form-control" value="<?php echo (getmodsbyid('7')) ; ?>"required>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Update Branding info</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h2 class="mb-4">Favicons</h2>
                            <h6 class="mb-4 text-info">‼️ Provide the link or path to the .png file for favicons. ‼️</h6>
                            <form  method="post">
                                <div class="mb-3">
                                    <input type="hidden" name="data[8][preffile]" value="Favicons32">
                                    <input type="hidden" name="data[8][preftype]" value="string">
                                    <input type="hidden" name="data[8][prefname]" value="Favicons">
                                    <label for="exampleInputEmail1" class="form-label">Favicon 32x32</label>
                                    <span class="text-warning">🚨 This is absolutely necessary.</span>
                                    <input type="text" name="data[8][mods]" class="form-control" value="<?php echo (getmodsbyid('8')) ; ?>"required>
                                </div>
                                <div class="mb-3">
                                    <input type="hidden" name="data[9][preffile]" value="Favicons16">
                                    <input type="hidden" name="data[9][preftype]" value="string">
                                    <input type="hidden" name="data[9][prefname]" value="Favicons">
                                    <label  class="form-label">Favicon 16x16</label>
                                    <span class="text-warning">🚨 This is absolutely necessary.</span>
                                    <input type="text" name="data[9][mods]" class="form-control" value="<?php echo (getmodsbyid('9')) ; ?>"required>
                                </div>
                                <div class="mb-3">
                                    <input type="hidden" name="data[10][preffile]" value="Faviconsapple">
                                    <input type="hidden" name="data[10][preftype]" value="string">
                                    <input type="hidden" name="data[10][prefname]" value="Favicons">
                                    <label  class="form-label">Apple touch icon 180x180</label>
                                    <span class="text-warning">⚠️ Not required, just add if possible..</span>
                                    <input type="text" name="data[10][mods]" class="form-control" value="<?php echo (getmodsbyid('10')) ; ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <input type="hidden" name="data[11][preffile]" value="Faviconsmanifest">
                                    <input type="hidden" name="data[11][preftype]" value="string">
                                    <input type="hidden" name="data[11][prefname]" value="Favicons">
                                    <label  class="form-label">Manifest</label>
                                    <span class="text-warning">⚠️ Not required, just add if possible..</span>
                                    <input type="text" name="data[11][mods]" class="form-control" value="<?php echo (getmodsbyid('11')) ; ?>">
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Update Favicons</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h2 class="mb-4">Footer</h2>
                            <input type="hidden" name="data[12][preffile]" value="Footer">
                            <input type="hidden" name="data[12][preftype]" value="string">
                            <input type="hidden" name="data[12][prefname]" value="Footer">
                            <form  method="post">
                            <select class="form-select mb-3" name="data[12][mods]">
                                <option value="enable" <?php echo (getmodsbyid('12') == 'enable') ? 'selected' : ''; ?>>Enable</option>
                                <option value="disable" <?php echo (getmodsbyid('12') == 'disable') ? 'selected' : ''; ?>>Disable</option>
                            </select>    
                                <button type="submit" name="submit" class="btn btn-primary">Update Footer</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>
</html>
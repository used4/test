<?php
include(__DIR__ . '/../includes/functions.php'); 

$getmac = isset($_GET['mac']) ? $_GET['mac'] : '';
$message = (!empty($_GET['msg'])) ? $_GET['msg'] : 'No comments';


function getCurrentDateTimeAuto() {
    $timezone = @date_default_timezone_get();
    if (!$timezone) {
        $timezone = 'UTC';
    }
    date_default_timezone_set($timezone);
    return date('Y-m-d H:i:s');
}

function saverequest($mac,$message,$date){
    global $db;
    $table_name = "actreq";

    $data = [
    'mac' => $mac,
    'date' => $date,
    'remark' => $message];
    
    if($mac == ''){
        return out(2);
    }else{
        $db->insert($table_name, $data);
	    $db->close();
	    return out(1);
    }
}


function out($status){
    $success = [
     'status' => 'success',
     'message' => "Successfully Send Request"
     ];
     
    $error = [
     'status' => 'error',
     'message' => 'There was a problem. Please try again later.'
     ]; 
     
     if($status == 1){
         return json_encode($success);
     }else{
         return json_encode($error);
     }
}


echo saverequest($getmac,$message,getCurrentDateTimeAuto());
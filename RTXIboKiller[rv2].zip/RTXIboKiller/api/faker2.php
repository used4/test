<?php
echo '{"url":"{ "id": 1, "url": "httpsjhhj://example.com", "created_at": "2023-03-16T07:28:18.000000Z", "updated_at": "2024-11-15T11:02:33.000000Z" }"}';
?>
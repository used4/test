<?php     
include(__DIR__ . '/../includes/functions.php');    
session_start();

$playlistname;
$getmac = isset($_GET['mac']) ? $_GET['mac'] : '';
$getuuid = isset($_GET['uuid']) ? $_GET['uuid'] : '';
$getname = isset($_GET['name']) ? $_GET['name'] : '';
$getuname = isset($_GET['uname']) ? $_GET['uname'] : '';
$getpassw = isset($_GET['pword']) ? $_GET['pword'] : '';

function PlaylistID() {
    $timezone = @date_default_timezone_get();
    if (!$timezone) {
        $timezone = 'UTC';
    }
    date_default_timezone_set($timezone);
    $time = date('Y-m-d H:i:s');
    $mix = md5($time).$time;
    return hash('sha256', $mix);
}

function getCurrentDateTimeAuto() {
    $timezone = @date_default_timezone_get();
    if (!$timezone) {
        $timezone = 'UTC';
    }
    date_default_timezone_set($timezone);
    return date('Y-m-d H:i:s');
}

function getRandomIPTVName() {
    $names = [
        "📺 UltraStream",
        "🎬 CineMax",
        "📡 NetWave",
        "🔥 FireStream",
        "🌐 GlobeTV",
        "🎥 MovieZone",
        "🌟 StarView",
        "📻 RadioCast",
        "💎 DiamondTV",
        "🌊 OceanStream",
        "🚀 RocketTV",
        "🎶 MusicFlow",
        "🍿 PopcornTime",
        "🛰️ SatView",
        "🎯 TargetStream",
        "📽️ FilmBox",
        "💫 GalaxyCast",
        "⚡ FlashStream",
        "🏆 PrimeTV",
        "🖥️ StreamX",
        "🌈 RainbowTV",
        "🎉 PartyStream",
        "🦅 EagleCast",
        "🏝️ IslandView",
        "🔮 VisionTV",
        "🎤 StageCast",
        "📦 BoxStream",
        "🛡️ ShieldView",
        "🌌 SpaceStream",
        "💥 BoomCast",
        "🎧 AudioWave",
        "🎭 DramaBox",
        "🌻 SunStream",
        "📊 InfoCast",
        "🐬 DolphinTV",
        "🪐 OrbitView",
        "🌴 TropicCast",
        "📜 StoryTV",
        "💃 DanceStream",
        "🥇 GoldCast"
    ];

    return $names[array_rand($names)];
}

if($getname == '' || $getname == 'ran'){
    $playlistname = getRandomIPTVName();
}else{
    $playlistname = $getname;
}

echo saveplaylist(PlaylistID(),$playlistname,$getmac,$getuuid,$getuname,$getpassw,getCurrentDateTimeAuto(),getCurrentDateTimeAuto());


function saveplaylist($pid,$name,$mac,$dnsuuid,$username,$password,$cdate,$udate){
    global $db;
    $table_name = "ibof";

    $data = [
    'plid' => $pid,
    'name' => $name,
    'macad' => $mac,
    'uuid' => $dnsuuid,
    'username' => $username,
    'password' => $password,
    'cdate' => $cdate,
    'udate' => $udate,
    'mark' => 0];
    
    if($mac == ''||$dnsuuid == ''||$name == ''||$username == ''||$password == ''){
        return out(2,$name);
    }else{
        $db->insert($table_name, $data);
	    $db->close();
	    return out(1,$name);
    }
        
    
}


function out($status ,$name){
    $success = [
     'status' => 'success',
     'message' => "Successfully added the playlist ➤ $name"
     ];
     
    $error = [
     'status' => 'error',
     'message' => 'There was a problem. Please try again later.'
     ]; 
     
     if($status == 1){
         return json_encode($success);
     }else{
         return json_encode($error);
     }
}
<?php
echo '{"url":"https://example.com"}';
?>
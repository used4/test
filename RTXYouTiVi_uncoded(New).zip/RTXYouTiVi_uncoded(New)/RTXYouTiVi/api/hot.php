<?php     
include(__DIR__ . '/../includes/functions.php');
session_start();      


$res = $db->select('leaguesx', '*', '', '');

$rowsJson = array();      


foreach ($res as $row) {      
    $row_array = array( 
        'idLeague' => $row['leagueId'],    
        'strLeague' => $row['league'],
        'strSport' => $row['lsports'],
        'strLeagueAlternate' => $row['league'],
    );
    $rowsJson[] = $row_array;    
}     

header('Content-Type: application/json');

$finalgood = json_encode(array(
    'leagues' => $rowsJson
    
));


echo $finalgood;
